# twitter-turkish-preprocess

A light-weight python package to pre-process Turkish Twitter Statuses(Tweets).