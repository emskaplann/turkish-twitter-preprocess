# twitter-turkish-preprocess

a light-weight python package to pre-process turkish twitter statuses(tweets).
